import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-staff-add-lazy',
  templateUrl: './staff-add-lazy.component.html',
  styleUrls: ['./staff-add-lazy.component.css']
})
export class StaffAddLazyComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
