import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StaffAddLazyComponent } from './staff-add-lazy.component';

describe('StaffAddLazyComponent', () => {
  let component: StaffAddLazyComponent;
  let fixture: ComponentFixture<StaffAddLazyComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ StaffAddLazyComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(StaffAddLazyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
