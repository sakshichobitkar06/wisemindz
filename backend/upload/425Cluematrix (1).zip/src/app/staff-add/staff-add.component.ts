import {
  Component, ComponentFactoryResolver,
  OnInit,
  TemplateRef,
  ViewChild,
  ViewContainerRef
} from '@angular/core';

@Component({
  selector: 'app-staff-add',
  templateUrl: './staff-add.component.html',
  styleUrls: ['./staff-add.component.css']
})
export class StaffAddComponent implements OnInit {

  @ViewChild(TemplateRef, { read: ViewContainerRef })             //access child component

  private templateViewContainerRef: any = ViewContainerRef;       //helps in inserting new component

  constructor(private readonly componentFactoryResolver: ComponentFactoryResolver) { }         //maps component 

  async ngOnInit() {
    import('../staff-add-lazy/staff-add-lazy.component').then(
      ({ StaffAddLazyComponent }) => {
        const component = this.componentFactoryResolver.resolveComponentFactory(
          StaffAddLazyComponent
        );
        const componentRef = this.templateViewContainerRef.createComponent(
          component
        );
      }
    );
  }

}
