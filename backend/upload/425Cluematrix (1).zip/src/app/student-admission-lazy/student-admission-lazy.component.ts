import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-student-admission-lazy',
  templateUrl: './student-admission-lazy.component.html',
  styleUrls: ['./student-admission-lazy.component.css']
})
export class StudentAdmissionLazyComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
