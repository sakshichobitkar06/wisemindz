import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StudentAdmissionLazyComponent } from './student-admission-lazy.component';

describe('StudentAdmissionLazyComponent', () => {
  let component: StudentAdmissionLazyComponent;
  let fixture: ComponentFixture<StudentAdmissionLazyComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ StudentAdmissionLazyComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(StudentAdmissionLazyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
