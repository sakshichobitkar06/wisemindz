import {
  Component, ComponentFactoryResolver,
  OnInit,
  TemplateRef,
  ViewChild,
  ViewContainerRef
} from '@angular/core';

@Component({
  selector: 'app-student-admission',
  templateUrl: './student-admission.component.html',
  styleUrls: ['./student-admission.component.css']
})
export class StudentAdmissionComponent implements OnInit {

  @ViewChild(TemplateRef, { read: ViewContainerRef })             //access child component

  private templateViewContainerRef: any = ViewContainerRef;       //helps in inserting new component

  constructor(private readonly componentFactoryResolver: ComponentFactoryResolver) { }         //maps component 

  async ngOnInit() {
    import('../student-admission-lazy/student-admission-lazy.component').then(
      ({ StudentAdmissionLazyComponent }) => {
        const component = this.componentFactoryResolver.resolveComponentFactory(
          StudentAdmissionLazyComponent
        );
        const componentRef = this.templateViewContainerRef.createComponent(
          component
        );
      }
    );
  }


}
