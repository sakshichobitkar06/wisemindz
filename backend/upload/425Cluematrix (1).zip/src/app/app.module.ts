import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { StudentAdmissionComponent } from './student-admission/student-admission.component';
import { StudentAdmissionLazyComponent } from './student-admission-lazy/student-admission-lazy.component';
import { StaffAddComponent } from './staff-add/staff-add.component';
import { StaffAddLazyComponent } from './staff-add-lazy/staff-add-lazy.component';
import { HeaderComponent } from './header/header.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';


@NgModule({
  declarations: [
    AppComponent,
    StudentAdmissionComponent,
    StudentAdmissionLazyComponent,
    StaffAddComponent,
    StaffAddLazyComponent,
    HeaderComponent,
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule, ReactiveFormsModule, BrowserAnimationsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
