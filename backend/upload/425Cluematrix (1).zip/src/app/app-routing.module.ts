import { NgModule } from '@angular/core';
import { RouterModule, Routes, PreloadAllModules } from '@angular/router';
import { StaffAddComponent } from './staff-add/staff-add.component';
import { StaffAddLazyComponent } from './staff-add-lazy/staff-add-lazy.component';
import { StudentAdmissionComponent } from './student-admission/student-admission.component';
import { StudentAdmissionLazyComponent } from './student-admission-lazy/student-admission-lazy.component';
import { HeaderComponent } from './header/header.component';


const routes: Routes = [
  { path: '', component: HeaderComponent },
  { path: 'staff-add', component: StaffAddComponent },
  { path: 'staff-add-lazy', component: StaffAddLazyComponent },
  { path: 'student-admission', component: StudentAdmissionComponent },
  { path: 'student-admission-lazy', component: StudentAdmissionLazyComponent }

];

@NgModule({
  imports: [RouterModule.forRoot(routes, {
    // preloading in modules
    preloadingStrategy: PreloadAllModules
  })],
  exports: [RouterModule]
})
export class AppRoutingModule { }
